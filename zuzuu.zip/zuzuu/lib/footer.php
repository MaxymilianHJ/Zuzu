<footer class="footer">
    ZuZu 2021
</footer>
</body>
</html>
