<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class QuestionController extends AbstractController
{

    /**
     * @Route("/")
     */
    public function homepage()
    {
        return new Response('What a bewitcing controller we have conjured!');
    }

    /**
     * @Route("/questions/{slug}")
     */
    public function show($slug)
    {
        $answers = [
            'make sure your cat is sitti ng purrfectly still',
            'Honestly, I like furry shoes better than My cat',
            'Maybe... try saying the spell backwards?'
        ];

        return $this->render('questions/show.html.twig',[
            'question' => ucwords(str_replace('-', '', $slug)),
            'answers' => $answers,
        ]);
    }
}